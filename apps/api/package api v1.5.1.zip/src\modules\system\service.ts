import fs from 'fs';
import path from 'path';
import axios from 'axios';
import FormData from 'form-data';
import { pipeline } from 'stream/promises';

// Target Frontend URL host in production
const DEWAHOSTER_URL = process.env.FRONTEND_URL || 'https://mandalotim.sch.id';
const UPDATE_SECRET = process.env.UPDATE_SECRET || 'MandaApp_Secret_Key_Update_2026!';
const GITHUB_REPO = 'pmjhaqqulyaqin/mandaapp';

export const getSystemStatus = async () => {
  let currentVersion = '1.0.0';
  try {
    const versionRes = await axios.get(`${DEWAHOSTER_URL}/version.json?t=${Date.now()}`);
    if (versionRes.data?.version) currentVersion = versionRes.data.version;
  } catch (e) {
    // silently fallback to 1.0.0
  }

  return {
    version: currentVersion,
    environment: process.env.NODE_ENV || 'development',
    uptime: process.uptime(),
    lastUpdate: null,
  };
};

export const checkForUpdates = async () => {
  try {
    const status = await getSystemStatus();
    const currentVersion = status.version;

    const headers: any = { 
      'Accept': 'application/vnd.github.v3+json',
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0'
    };
    
    // Optional: Personal Access Token if provided in env
    if (process.env.GITHUB_TOKEN) {
      headers['Authorization'] = `token ${process.env.GITHUB_TOKEN}`;
    }

    // Append ?t=Date.now() to trick caching mechanisms
    const ghRes = await axios.get(`https://api.github.com/repos/${GITHUB_REPO}/releases/latest?t=${Date.now()}`, {
      headers,
      timeout: 10000
    });

    const latestRelease = ghRes.data;
    const remoteVersion = latestRelease.tag_name.replace(/^v/, '');

    return {
      currentVersion: currentVersion,
      latestVersion: remoteVersion,
      hasUpdate: remoteVersion !== currentVersion,
      releaseNotes: latestRelease.body || "Pembaruan GitHub ditemukan.",
      updateType: 'System',
      downloadUrl: latestRelease.assets.find((a: any) => a.name.endsWith('.zip'))?.browser_download_url || null
    };
  } catch (error: any) {
    console.error('Check updates failed:', error.message);
    throw new Error('Gagal memeriksa pembaruan dari GitHub: ' + (error.response?.data?.message || error.message));
  }
};

export const processUpdatePackage = async (filePath: string) => {
  try {
    const fileStream = fs.createReadStream(filePath);
    const formData = new FormData();
    formData.append('package', fileStream, { filename: 'update.zip' });

    const targetUrl = `${DEWAHOSTER_URL}/system-updater.php?action=update`;

    const response = await axios.post(targetUrl, formData, {
      headers: {
        ...formData.getHeaders(),
        'Authorization': `Bearer ${UPDATE_SECRET}`,
      },
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
      timeout: 180000 // 3 minutes timeout for large file transfer & extraction
    });

    return {
      success: true,
      message: response.data.message || 'Paket update berhasil diterapkan ke server Frontend!',
      targetVersion: 'manual-update'
    };
  } catch (error: any) {
    console.error('Update bridge failed:', error.response?.data || error.message);
    throw new Error(error.response?.data?.error || 'Gagal mengirim paket pembaruan ke server Dewahoster.');
  } finally {
    // Bersihkan file sementara .zip jika berhasil maupun gagal
    try {
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    } catch (e) {
      console.error('Failed to cleanup temp upload file', e);
    }
  }
};

export const rollbackUpdatePackage = async () => {
  try {
    const targetUrl = `${DEWAHOSTER_URL}/system-updater.php?action=rollback`;

    const response = await axios.get(targetUrl, {
      headers: {
        'Authorization': `Bearer ${UPDATE_SECRET}`,
      },
      timeout: 60000 
    });

    return {
      success: true,
      message: response.data.message || 'Sistem berhasil di-rollback ke versi sebelumnya!'
    };
  } catch (error: any) {
    console.error('Rollback bridge failed:', error.response?.data || error.message);
    throw new Error(error.response?.data?.error || 'Sedang tidak ada backup untuk di-rollback atau terjadi kegagalan.');
  }
};

export const syncGithubUpdate = async () => {
  try {
    const updateInfo = await checkForUpdates();
    if (!updateInfo.downloadUrl) {
      throw new Error('Tidak ada file .zip yang dilampirkan pada Release GitHub terbaru.');
    }

    console.log('Forwarding GitHub Asset URL to Dewahoster:', updateInfo.downloadUrl);
    
    const targetUrl = `${DEWAHOSTER_URL}/system-updater.php?action=download_update`;
    const response = await axios.post(targetUrl, { url: updateInfo.downloadUrl }, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${UPDATE_SECRET}`,
      },
      timeout: 120000 // 2 minutes timeout for remote download & extract
    });

    return {
      success: true,
      message: response.data?.message || 'Sukses! Aplikasi berhasil disinkronisasi dengan GitHub Release terbaru.',
      targetVersion: updateInfo.latestVersion
    };
  } catch (error: any) {
    console.error('GitHub Sync Bridge Failed:', error.response?.data || error.message);
    throw new Error('Gagal sinkronisasi GitHub: ' + (error.response?.data?.error || error.response?.data?.message || error.message));
  }
};
